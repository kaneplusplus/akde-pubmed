#' datadr.
#'
#' @name datadr
#' @docType package
#' @import parallel data.table digest hexbin

NULL

#' "Census Income" Dataset
#'
#' @name adult
#' @docType data
#' @description
#' "Census Income" dataset from UCI machine learning repository
#' @usage adult
#' @format
#' (From UCI machine learning repository)
#'
#' \itemize{
#'   \item age. continuous
#'   \item workclass. Private, Self-emp-not-inc, Self-emp-inc, Federal-gov, Local-gov, State-gov, Without-pay, Never-worked
#'   \item fnlwgt. continuous
#'   \item education. Bachelors, Some-college, 11th, HS-grad, Prof-school, Assoc-acdm, Assoc-voc, 9th, 7th-8th, 12th, Masters, 1st-4th, 10th, Doctorate, 5th-6th, Preschool
#'   education-num: continuous
#'   \item marital. Married-civ-spouse, Divorced, Never-married, Separated, Widowed, Married-spouse-absent, Married-AF-spouse
#'   \item occupation. Tech-support, Craft-repair, Other-service, Sales, Exec-managerial, Prof-specialty, Handlers-cleaners, Machine-op-inspct, Adm-clerical, Farming-fishing, Transport-moving, Priv-house-serv, Protective-serv, Armed-Forces
#'   \item relationship. Wife, Own-child, Husband, Not-in-family, Other-relative, Unmarried
#'   \item race. White, Asian-Pac-Islander, Amer-Indian-Eskimo, Other, Black
#'   \item sex. Female, Male
#'   \item capgain. continuous
#'   \item caploss. continuous
#'   \item hoursperweek. continuous
#'   \item nativecountry. United-States, Cambodia, England, Puerto-Rico, Canada, Germany, Outlying-US(Guam-USVI-etc), India, Japan, Greece, South, China, Cuba, Iran, Honduras, Philippines, Italy, Poland, Jamaica, Vietnam, Mexico, Portugal, Ireland, France, Dominican-Republic, Laos, Ecuador, Taiwan, Haiti, Columbia, Hungary, Guatemala, Nicaragua, Scotland, Thailand, Yugoslavia, El-Salvador, Trinadad&Tobago, Peru, Hong, Holand-Netherlands
#'   \item income. <=50K, >50K
#'   \item incomebin. 0 if income<=50K, 1 if income>50K
#' }
#'
#' @source
#' (From UCI machine learning repository)
#' Link: \url{http://archive.ics.uci.edu/ml/datasets/Adult}
#' Donor:
#' Ronny Kohavi and Barry Becker
#' Data Mining and Visualization
#' Silicon Graphics.
#' e-mail: ronnyk@@live.com for questions.
#'
#' Data Set Information:
#' Extraction was done by Barry Becker from the 1994 Census database. A set of reasonably clean records was extracted using the following conditions: ((AAGE>16) && (AGI>100) && (AFNLWGT>1)&& (HRSWK>0))
#' @references Bache, K. & Lichman, M. (2013). UCI Machine Learning Repository [\url{http://archive.ics.uci.edu/ml}]. Irvine, CA: University of California, School of Information and Computer Science.
#' @keywords data
NULL
