library(testthat)

test_check("datadr")
