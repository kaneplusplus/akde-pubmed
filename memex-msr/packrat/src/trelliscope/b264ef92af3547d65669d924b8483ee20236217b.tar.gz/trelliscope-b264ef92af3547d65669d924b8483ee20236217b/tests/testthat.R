library(testthat)

test_check("trelliscope")
